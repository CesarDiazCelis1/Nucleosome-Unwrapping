from chimerax.core.commands import run
import numpy as np
run(session, 'windowsize 1000 1000')
run(session, 'set bgColor white')
run(session, 'lighting full')

import glob
co=1


distfile=np.loadtxt('dist.txt')
distfile = np.delete(distfile, (0), axis=0)
print(distfile)
print(int(distfile[0][0]))
numofmodel=170


###33 now record the movie


run(session, 'hide all models')
run(session, 'show #1 models')
run(session, 'view pos2')
#run(session, 'view orient')

run(session, 'sel #1-200/G,H,D,C')
run(session, 'color sel lawn green')
run(session, 'sel clear')


run(session, 'zoom 0.3')
run(session, 'hide #1 models')

#run(session, 'movie record supersample 6 size 1000,1000')
for idn in range(1,numofmodel+1):

    run(session, 'show #'+str(idn)+ ' models')
    run(session, 'show #'+str(idn+numofmodel)+ ' models')
    run(session, 'show #'+str(idn+2*numofmodel)+ ' models')
    run(session, 'show #'+str(idn+3*numofmodel)+ ' models')
    run(session, 'show #'+str(idn+4*numofmodel)+ ' models')
    run(session, 'show #'+str(idn+5*numofmodel)+ ' models')
    #run(session, '2dlabels text "Distal ends distance: '+str(round(distfile[idn-1][1]/10, 1))+' nm" color light sea green size 24 xpos .36 ypos .8')



    run(session, '2dlabels text "Distance between DNA entry-exit points: '+str(round(distfile[idn-1][1]/10, 1))+' nm" color light sea green size 24 xpos .16 ypos .8')



    idnxxx=idn
    if idnxxx < 24:
        idnxxx =24
    run(session, '2dlabels text "Change of extension: '+str(round(distfile[idn-1][1]/10, 1))+ ' nm - (-1.4 nm) + 0.34 nm/bp x' + str(idnxxx-24)+'bp = ' +str(round(1.4 + distfile[idn-1][1]/10 + 0.34*(idnxxx-24), 1))+' nm" color light sea green size 24 xpos .16 ypos .73')




    #run(session, 'wait 5')
    run(session, 'save  ./zzzz-movieFrame/'+ str(idn).zfill(3)+'.tif format tiff  supersample 2 ')
    #run(session, 'wait 5')


    run(session, 'hide #'+str(idn)+ ' models')
    run(session, 'hide #'+str(idn+numofmodel)+ ' models')
    run(session, 'hide #'+str(idn+2*numofmodel)+ ' models')
    run(session, 'hide #'+str(idn+3*numofmodel)+ ' models')
    run(session, 'hide #'+str(idn+4*numofmodel)+ ' models')
    run(session, 'hide #'+str(idn+5*numofmodel)+ ' models')
    run(session, '2dlabels delete')

    #break
#run(session, 'movie encode quality highest format avi output refine.avi bitrate 25000')


#session.logger.status("Processing file")
