from chimerax.core.commands import run
import numpy as np
run(session, 'windowsize 1000 1000')
run(session, 'set bgColor white')
run(session, 'lighting soft')


import glob
co=1

for elem in sorted(glob.glob("zz*.pdb"))[1:]:
    print(elem)
    run(session, "open "+elem)
    run(session, "hide atoms")

#    run(session, 'select #'+str(co)+' & nucleic-acid')
#    run(session, 'color sel #7B68EE')
#    run(session, 'show sel cartoons')

    run(session, 'select #'+str(co)+' & protein')
    run(session, 'color sel #FF7F50')
    run(session, 'show sel cartoons')

    run(session, 'select clear')
    run(session, 'hide #'+str(co)+ ' models')
    co+=1



numofmodel=co-1
for elem in sorted(glob.glob("zz*.bild"))[1:]:
    print(elem)
    run(session, "open "+elem)
    run(session, 'hide #'+str(co)+ ' models')
    co+=1



co=1
for elem in sorted(glob.glob("zz*.pdb"))[1:]:
    run(session, "sel #"+str(co)+"/M@P1,P2,P3/I/N@P2,P3,P4")
    run(session, "shape tube sel radius 8.5 color #7B68EE")
    co+=1

co=1
for elem in sorted(glob.glob("zz*.pdb"))[1:]:
    run(session, "shape sphere radius 11 center #"+str(co)+"/X@L1 color yellow")
    co+=1

co=1
for elem in sorted(glob.glob("zz*.pdb"))[1:]:
    run(session, "shape sphere radius 11 center #"+str(co)+"/X@R1 color yellow")
    co+=1

co=1
for elem in sorted(glob.glob("zz*.pdb"))[1:]:
    run(session, "shape sphere radius 11 center #"+str(co)+"/X@R2 color red")
    co+=1









run(session, 'cartoon style width 1.5 thick 3 ')
run(session, 'view name pos1 ')
run(session, 'turn x 180 center 0,0,0 ')
run(session, 'view name pos2 ')
run(session, 'save z3-loadedmdoel2.cxs')


