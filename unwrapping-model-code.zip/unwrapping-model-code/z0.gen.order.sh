
unb=27

########### first part 
for i in `seq 1 $unb`;do
    printf "%s " $i
done



###sysmtry, leave 15 bp each side at the end
rest=`echo "73-21-$unb" | bc`

for i in `seq 1 $rest`;do
    a=`echo "(147-$i)" | bc`
    b=`echo "($unb + $i)" | bc`

    printf "%s " $a
    printf "%s " $b
done


################# third part
for i in `seq 122 -1 92`;do

 

    printf "%s " $i
done




############################

for i in `seq 0 21`;do
    aaa=`echo "(53 + $i)" | bc`
    bbb=`echo "(91 - $i)" | bc`
    printf "%s " $aaa
    printf "%s " $bbb
done





rm zz*.bild
rm zz*.pdb
